<template>
  <router-view />
</template>

<script setup>
</script>

<style>
#app {
  min-height: 100vh;
}
</style>
